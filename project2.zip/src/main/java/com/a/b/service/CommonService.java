package com.a.b.service;
import org.springframework.ui.Model;
public interface CommonService {
	public void execute(Model model);
}
